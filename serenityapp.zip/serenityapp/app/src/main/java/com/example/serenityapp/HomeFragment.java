package com.example.serenityapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class HomeFragment extends Fragment {

    private LinearLayout containerMoodHistory;
    private CardView cardMood, cardTips;
    private SharedPreferences sharedPreferences;
    private TextView tvGreeting;

    private static final String PREF_NAME = "MoodPrefs";
    private static final String KEY_HISTORY = "moodHistory";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // 🔹 init view
        containerMoodHistory = view.findViewById(R.id.historyContainer);
        cardMood = view.findViewById(R.id.cardMood);
        cardTips = view.findViewById(R.id.cardTips);
        tvGreeting = view.findViewById(R.id.tvGreeting);

        sharedPreferences = requireContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        // 🔹 tampilkan greeting berdasarkan negara
        showGreeting();

        // 🔹 tampilkan riwayat mood
        loadMoodHistory();

        // 🔹 navigasi ke Mood
        cardMood.setOnClickListener(v -> {
            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.frame_container, new MoodFragment())
                    .addToBackStack(null)
                    .commit();

            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).setActiveNav(R.id.nav_mood);
            }
        });

        // 🔹 navigasi ke Tips
        cardTips.setOnClickListener(v -> {
            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.frame_container, new TipsFragment())
                    .addToBackStack(null)
                    .commit();

            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).setActiveNav(R.id.nav_tips);
            }
        });

        return view;
    }

    // ================= GREETING =================
    private void showGreeting() {

        SharedPreferences prefs = requireContext()
                .getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);

        String country = prefs.getString("country", "Unknown");

        Map<String, String> greetings = new HashMap<>();

        // 🌏 Asia
        greetings.put("Indonesia", "Halo 🌿 Selamat datang di Serenity 🇮🇩");
        greetings.put("Malaysia", "Hai 🌿 Selamat datang di Serenity 🇲🇾");
        greetings.put("Singapore", "Hello 🌿 Welcome to Serenity 🇸🇬");
        greetings.put("Thailand", "สวัสดี 🌿 ยินดีต้อนรับสู่ Serenity 🇹🇭");
        greetings.put("Vietnam", "Xin chào 🌿 Chào mừng đến Serenity 🇻🇳");
        greetings.put("Philippines", "Hello 🌿 Welcome to Serenity 🇵🇭");
        greetings.put("Japan", "こんにちは 🌿 Serenityへようこそ 🇯🇵");
        greetings.put("South Korea", "안녕하세요 🌿 Serenity에 오신 것을 환영합니다 🇰🇷");
        greetings.put("China", "你好 🌿 欢迎来到 Serenity 🇨🇳");
        greetings.put("India", "Namaste 🌿 Welcome to Serenity 🇮🇳");

        // 🌍 Eropa
        greetings.put("United Kingdom", "Hello 🌿 Welcome to Serenity 🇬🇧");
        greetings.put("France", "Bonjour 🌿 Bienvenue à Serenity 🇫🇷");
        greetings.put("Germany", "Hallo 🌿 Willkommen bei Serenity 🇩🇪");
        greetings.put("Italy", "Ciao 🌿 Benvenuto a Serenity 🇮🇹");
        greetings.put("Spain", "Hola 🌿 Bienvenido a Serenity 🇪🇸");
        greetings.put("Netherlands", "Hallo 🌿 Welkom bij Serenity 🇳🇱");
        greetings.put("Russia", "Привет 🌿 Добро пожаловать в Serenity 🇷🇺");
        greetings.put("Sweden", "Hej 🌿 Welcome to Serenity 🇸🇪");
        greetings.put("Norway", "Hei 🌿 Welcome to Serenity 🇳🇴");
        greetings.put("Finland", "Hei 🌿 Welcome to Serenity 🇫🇮");

        // 🌎 Amerika
        greetings.put("United States", "Hello 🌿 Welcome to Serenity 🇺🇸");
        greetings.put("Canada", "Hello 🌿 Welcome to Serenity 🇨🇦");
        greetings.put("Mexico", "Hola 🌿 Bienvenido a Serenity 🇲🇽");
        greetings.put("Brazil", "Olá 🌿 Bem-vindo ao Serenity 🇧🇷");
        greetings.put("Argentina", "Hola 🌿 Bienvenido a Serenity 🇦🇷");
        greetings.put("Chile", "Hola 🌿 Bienvenido a Serenity 🇨🇱");

        // 🌍 Timur Tengah & Afrika
        greetings.put("Saudi Arabia", "مرحبا 🌿 أهلاً بك في Serenity 🇸🇦");
        greetings.put("United Arab Emirates", "مرحبا 🌿 أهلاً بك في Serenity 🇦🇪");
        greetings.put("Egypt", "مرحبا 🌿 أهلاً بك في Serenity 🇪🇬");
        greetings.put("South Africa", "Hello 🌿 Welcome to Serenity 🇿🇦");
        greetings.put("Nigeria", "Hello 🌿 Welcome to Serenity 🇳🇬");

        // 🌏 Oseania
        greetings.put("Australia", "G'day 🌿 Welcome to Serenity 🇦🇺");
        greetings.put("New Zealand", "Hello 🌿 Welcome to Serenity 🇳🇿");

        // 🔹 fallback
        String greeting = greetings.getOrDefault(
                country,
                "Welcome 🌿 Find your calm in Serenity"
        );

        tvGreeting.setText(greeting);
    }



    // ================= MOOD HISTORY =================
    private void loadMoodHistory() {
        containerMoodHistory.removeAllViews();
        String historyJson = sharedPreferences.getString(KEY_HISTORY, "[]");

        try {
            JSONArray jsonArray = new JSONArray(historyJson);

            if (jsonArray.length() == 0) {
                showEmptyMessage();
                return;
            }

            for (int i = jsonArray.length() - 1; i >= 0; i--) {
                JSONObject moodObj = jsonArray.optJSONObject(i);
                if (moodObj == null) continue;

                String mood = moodObj.optString("mood", "-");
                String note = moodObj.optString("note", "");
                String date = moodObj.optString("date", "-");

                View item = LayoutInflater.from(getContext())
                        .inflate(R.layout.item_mood_history, containerMoodHistory, false);

                TextView tvMood = item.findViewById(R.id.tvMood);
                TextView tvNote = item.findViewById(R.id.tvNote);
                TextView tvDate = item.findViewById(R.id.tvDate);

                tvMood.setText("Mood: " + mood);
                tvNote.setText(note.isEmpty() ? "Tidak ada catatan." : "Catatan: " + note);
                tvDate.setText("Tanggal: " + date);

                containerMoodHistory.addView(item);
            }

        } catch (JSONException e) {
            e.printStackTrace();
            showEmptyMessage();
        }
    }

    private void showEmptyMessage() {
        TextView emptyView = new TextView(getContext());
        emptyView.setText("     Belum ada catatan mood tersimpan.");
        containerMoodHistory.addView(emptyView);
    }
}
