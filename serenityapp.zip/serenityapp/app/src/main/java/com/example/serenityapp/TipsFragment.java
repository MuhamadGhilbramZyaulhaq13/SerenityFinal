package com.example.serenityapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;

import java.util.ArrayList;
import java.util.List;

public class TipsFragment extends Fragment {

    private RecyclerView recyclerTips;
    private TipsAdapter tipsAdapter;
    private List<TipItem> tipList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tips, container, false);

        recyclerTips = view.findViewById(R.id.recyclerTips);
        recyclerTips.setLayoutManager(new LinearLayoutManager(getContext()));

        // 🔹 Data dummy
        tipList = new ArrayList<>();
        tipList.add(new TipItem("Mindfulness", "Bernapas dengan Tenang",
                "Tarik napas dalam-dalam selama 4 detik, tahan 4 detik, lalu hembuskan perlahan selama 6 detik. Ulangi 3 kali untuk menenangkan pikiran."));
        tipList.add(new TipItem("Self-Care", "Gratitude Moment",
                "Sebutkan 3 hal yang kamu syukuri hari ini, sekecil apapun itu. Rasa syukur dapat meningkatkan mood dan kebahagiaan."));
        tipList.add(new TipItem("Motivasi", "Kamu Cukup",
                "Tidak perlu sempurna untuk pantas dicintai dan dihargai. Kamu sudah cukup dengan apa adanya. Terimalah dirimu dengan penuh kasih sayang."));
        tipList.add(new TipItem("Mindfulness", "Mindful Walking",
                "Saat berjalan, rasakan setiap langkahmu. Perhatikan suara, aroma, dan pemandangan sekitar. Hadirkan diri sepenuhnya di momen ini."));
        tipList.add(new TipItem("Self-Care", "Me-Time Moment",
                "Luangkan 10 menit untuk dirimu sendiri. Lakukan hal sederhana yang membuatmu bahagia - mendengar musik, minum teh, atau sekadar diam."));
        tipList.add(new TipItem("Self-Care", "Journal Sederhana",
                "Tulis 3 kalimat tentang perasaanmu saat ini. Tidak perlu panjang, cukup ekspresikan apa yang ada di hatimu."));
        tipList.add(new TipItem("Motivasi", "Langkah Kecil Penting",
                "Setiap langkah kecil yang kamu ambil hari ini adalah kemajuan. Hargai prosesmu, bukan hanya hasilnya."));
        tipList.add(new TipItem("Motivasi", "Langkah Kecil Penting",
                "Kemajuan tidak selalu terlihat besar. Kadang kemajuan adalah bangun dari tempat tidur, mandi, atau tersenyum. Semua itu berharga."));

        tipsAdapter = new TipsAdapter(tipList, getContext());
        recyclerTips.setAdapter(tipsAdapter);

        // 🔸 Ambil chip dari layout
        Chip chipSemua = view.findViewById(R.id.chipSemua);
        Chip chipMindfulness = view.findViewById(R.id.chipMindfulness);
        Chip chipSelfCare = view.findViewById(R.id.chipSelfCare);
        Chip chipMotivasi = view.findViewById(R.id.chipMotivasi);

        // “Semua”
        chipSemua.setOnClickListener(v -> tipsAdapter.updateList(tipList));

        // “Mindfulness”
        chipMindfulness.setOnClickListener(v -> filterCategory("Mindfulness"));

        // “Self-Care”
        chipSelfCare.setOnClickListener(v -> filterCategory("Self-Care"));

        // “Motivasi”
        chipMotivasi.setOnClickListener(v -> filterCategory("Motivasi"));

        return view;
    }

    // 🔹 Fungsi filter kategori
    private void filterCategory(String category) {
        List<TipItem> filtered = new ArrayList<>();
        for (TipItem item : tipList) {
            if (item.getCategory().equals(category)) {
                filtered.add(item);
            }
        }
        tipsAdapter.updateList(filtered);
    }
}
