package com.example.serenityapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MoodFragment extends Fragment {

    private Button btnSad, btnUnwell, btnNeutral, btnGood, btnGreat, btnSaveMood;
    private EditText etNote;
    private String selectedMood = "";

    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "MoodPrefs";
    private static final String KEY_HISTORY = "moodHistory";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_mood, container, false);

        // Hubungkan komponen dari XML
        btnSad = view.findViewById(R.id.btnSad);
        btnUnwell = view.findViewById(R.id.btnUnwell);
        btnNeutral = view.findViewById(R.id.btnNeutral);
        btnGood = view.findViewById(R.id.btnGood);
        btnGreat = view.findViewById(R.id.btnGreat);
        btnSaveMood = view.findViewById(R.id.btnSaveMood);
        etNote = view.findViewById(R.id.etNote);

        sharedPreferences = requireContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        Button[] moodButtons = {btnSad, btnUnwell, btnNeutral, btnGood, btnGreat};

        int defaultColor = Color.parseColor("#FFFFFF");
        int selectedColor = Color.parseColor("#FFF59D");

        // Listener mood
        View.OnClickListener moodClickListener = v -> {
            for (Button b : moodButtons) {
                b.setBackgroundTintList(ColorStateList.valueOf(defaultColor));
            }

            Button clickedButton = (Button) v;
            clickedButton.setBackgroundTintList(ColorStateList.valueOf(selectedColor));

            selectedMood = clickedButton.getText().toString().replace("\n", " ");
        };

        for (Button b : moodButtons) {
            b.setOnClickListener(moodClickListener);
        }

        // Tombol Simpan
        btnSaveMood.setOnClickListener(v -> {
            String note = etNote.getText().toString().trim();

            if (selectedMood.isEmpty()) {
                Toast.makeText(getContext(), "Pilih mood terlebih dahulu!", Toast.LENGTH_SHORT).show();
                return;
            }

            // 🔹 Buat timestamp (tanggal dan waktu)
            String currentTime = new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
                    .format(new Date());

            // 🔹 Simpan ke JSON Array (riwayat)
            try {
                String existingData = sharedPreferences.getString(KEY_HISTORY, "[]");
                JSONArray jsonArray = new JSONArray(existingData);

                JSONObject newEntry = new JSONObject();
                newEntry.put("mood", selectedMood);
                newEntry.put("note", note);
                newEntry.put("date", currentTime);

                jsonArray.put(newEntry);

                sharedPreferences.edit().putString(KEY_HISTORY, jsonArray.toString()).apply();


            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(getContext(), "Gagal menyimpan mood.", Toast.LENGTH_SHORT).show();
            }

            // 🔹 Reset tampilan form setelah disimpan
            etNote.setText("");
            selectedMood = "";
            resetMoodSelection(moodButtons, defaultColor);
        });

        // 🧹 Reset otomatis ketika halaman dibuka
        resetMoodSelection(moodButtons, defaultColor);
        etNote.setText("");
        selectedMood = "";

        return view;
    }

    private void resetMoodSelection(Button[] moodButtons, int defaultColor) {
        for (Button b : moodButtons) {
            b.setBackgroundTintList(ColorStateList.valueOf(defaultColor));
        }
    }
}
