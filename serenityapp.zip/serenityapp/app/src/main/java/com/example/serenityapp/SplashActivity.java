package com.example.serenityapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class SplashActivity extends AppCompatActivity {

    private static final int LOCATION_REQUEST_CODE = 100;

    private FusedLocationProviderClient fusedLocationClient;
    private TextView locationText;

    // 🔹 TAMBAHAN (loading dots)
    private TextView tvDots;
    private Handler dotHandler = new Handler(Looper.getMainLooper());
    private int dotCount = 1;

    private String detectedCountry = "Unknown";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        locationText = findViewById(R.id.locationText);

        // 🔹 TAMBAHAN
        tvDots = findViewById(R.id.tvDots);
        startDotAnimation();

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        getUserLocation();
    }

    private void getUserLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_REQUEST_CODE
            );
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                getCountryFromLocation(location);
            } else {
                locationText.setText("🌍 Lokasi tidak tersedia");
            }

            lanjutKeMain();
        });
    }

    private void getCountryFromLocation(Location location) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(
                    location.getLatitude(),
                    location.getLongitude(),
                    1
            );

            if (addresses != null && !addresses.isEmpty()) {
                String countryName = addresses.get(0).getCountryName();
                String countryCode = addresses.get(0).getCountryCode();

                detectedCountry = countryName;
                String flagEmoji = getFlagEmoji(countryCode);

                locationText.setText(flagEmoji + " " + countryName);
            }
        } catch (IOException e) {
            e.printStackTrace();
            locationText.setText("🌍 Gagal mendeteksi lokasi");
        }
    }

    private String getFlagEmoji(String countryCode) {
        if (countryCode == null || countryCode.length() != 2) return "🌍";

        int firstChar = Character.codePointAt(countryCode, 0) - 0x41 + 0x1F1E6;
        int secondChar = Character.codePointAt(countryCode, 1) - 0x41 + 0x1F1E6;

        return new String(Character.toChars(firstChar))
                + new String(Character.toChars(secondChar));
    }

    private void lanjutKeMain() {
        new Handler().postDelayed(() -> {

            SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
            prefs.edit()
                    .putString("country", detectedCountry)
                    .apply();

            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(intent);
            finish();

        }, 3000);
    }

    // 🔹 TAMBAHAN: animasi loading dots
    private void startDotAnimation() {
        dotHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                StringBuilder dots = new StringBuilder();
                for (int i = 0; i < dotCount; i++) {
                    dots.append("● ");
                }

                tvDots.setText(dots.toString().trim());

                // fade lembut
                tvDots.setAlpha(0.3f);
                tvDots.animate().alpha(1f).setDuration(300).start();

                dotCount++;
                if (dotCount > 3) {
                    dotCount = 1;
                }

                dotHandler.postDelayed(this, 500);
            }
        }, 500);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 🔹 TAMBAHAN: cegah memory leak
        dotHandler.removeCallbacksAndMessages(null);
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST_CODE
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            getUserLocation();
        } else {
            locationText.setText("🌍 Izin lokasi ditolak");
            lanjutKeMain();
        }
    }
}
