package com.example.serenityapp;

public class MoodEntry {
    private String mood;
    private String note;
    private String timestamp;

    public MoodEntry(String mood, String note, String timestamp) {
        this.mood = mood;
        this.note = note;
        this.timestamp = timestamp;
    }

    public String getMood() {
        return mood;
    }

    public String getNote() {
        return note;
    }

    public String getTimestamp() {
        return timestamp;
    }
}
