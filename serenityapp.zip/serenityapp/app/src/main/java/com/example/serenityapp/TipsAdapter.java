package com.example.serenityapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TipsAdapter extends RecyclerView.Adapter<TipsAdapter.TipsViewHolder> {

    private List<TipItem> tipList;
    private Context context;

    public TipsAdapter(List<TipItem> tipList, Context context) {
        this.tipList = new ArrayList<>(tipList);
        this.context = context;
    }

    @NonNull
    @Override
    public TipsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tips, parent, false);
        return new TipsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TipsViewHolder holder, int position) {
        TipItem tip = tipList.get(position);

        holder.tvCategory.setText(tip.getCategory());
        holder.tvTitle.setText(tip.getTitle());
        holder.tvDescription.setText(tip.getDescription());

        holder.itemView.setOnClickListener(v ->
                Toast.makeText(context, "Kamu memilih: " + tip.getTitle(), Toast.LENGTH_SHORT).show());
    }

    @Override
    public int getItemCount() {
        return tipList.size();
    }

    public void updateList(List<TipItem> newList) {
        tipList.clear();
        tipList.addAll(newList);
        notifyDataSetChanged();
    }

    public static class TipsViewHolder extends RecyclerView.ViewHolder {
        TextView tvCategory, tvTitle, tvDescription;

        public TipsViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDescription = itemView.findViewById(R.id.tvDescription);
        }
    }
}
